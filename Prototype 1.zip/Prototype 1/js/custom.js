$(".portfolio-box-caption").click(function(){
    console.log("clicked")
        var offset = 20; //Offset of 20px

        $('html, body').animate({
            scrollTop: $("#about").offset().top + offset
        }, 2000);

});
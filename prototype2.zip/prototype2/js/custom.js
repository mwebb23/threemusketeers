$("#box-1").click(function(){
    var offset = 20; //Offset of 20px

    $('html, body').animate({
        scrollTop: $("#vis-1").offset().top + offset
    }, 2000);
});

$("#box-2").click(function(){
    var offset = 20; //Offset of 20px

    $('html, body').animate({
        scrollTop: $("#vis-2").offset().top + offset
    }, 2000);
});

$("#box-3").click(function(){
    var offset = 20; //Offset of 20px

    $('html, body').animate({
        scrollTop: $("#vis-3").offset().top + offset
    }, 2000);
});

$("#box-4").click(function(){
    var offset = 20; //Offset of 20px

    $('html, body').animate({
        scrollTop: $("#vis-4").offset().top + offset
    }, 2000);
});

$("#box-5").click(function(){
    var offset = 20; //Offset of 20px

    $('html, body').animate({
        scrollTop: $("#vis-5").offset().top + offset
    }, 2000);
});

$("#box-6").click(function(){
    var offset = 20; //Offset of 20px

    $('html, body').animate({
        scrollTop: $("#vis-6").offset().top + offset
    }, 2000);
});
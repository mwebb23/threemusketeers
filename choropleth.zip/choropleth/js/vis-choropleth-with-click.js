var margin = { top: 10, right: 40, bottom: 10, left: 40 };

var width = $("body").width() - margin.left - margin.right;
var height = 620 - margin.top - margin.bottom;

var svg = d3.select("#map-area").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom);

var color = d3.scaleThreshold()
    .range(["#fff5f0","#fee0d2","#fcbba1","#fc9272","#fb6a4a","#ef3b2c","#cb181d","#a50f15","#67000d"]);

queue()
  .defer(d3.json, "data/world-countries.json")
  .defer(d3.csv, "data/cocoa_exports.csv")
    .defer(d3.csv, "data/cocoa_imports.csv")
    .defer(d3.csv, "data/chocolate_exports.csv")
    .defer(d3.csv, "data/chocolate_imports.csv")
  .await(function(error, mapTopJson, cocoaExportData, cocoaImportData, chocolateExportData, chocolateImportData){

      worldMap = topojson.feature(mapTopJson, mapTopJson.objects.countries1).features;

      cocoaExportData.forEach(function(d){
          d.val = +d.val;
      });
      chocolateExportData.forEach(function(d){
          d.val = +d.val;
      });
      cocoaImportData.forEach(function(d){
          d.val = +d.val;
      });
      chocolateImportData.forEach(function(d){
          d.val = +d.val;
      });

      cocoa_Ex = cocoaExportData;
      cocoa_Im = cocoaImportData;
      chocolate_Ex = chocolateExportData;
      chocolate_Im = chocolateImportData;

    updateChoropleth();
  });

function updateChoropleth() {

    selected = d3.select("#statistic").property("value");
    DataByCountryID = {};
    
    if (selected === "Cocoa Exports")
        worldData = cocoa_Ex.filter(function(d){return (d.other_country === "ALL")});
    else if (selected === "Cocoa Imports")
        worldData = cocoa_Im.filter(function (d) {return (d.other_country === "ALL")});
    else if (selected === "Chocolate Exports")
        worldData = chocolate_Ex.filter(function (d) {return (d.other_country === "ALL")});
    else if (selected === "Chocolate Imports")
        worldData = chocolate_Im.filter(function (d) {return (d.other_country === "ALL")});

    worldData.forEach(function(d){DataByCountryID[d.focus_country] = d;});

    color.domain([1, 10, 50, 100, 250, 500, 1000, 2500]);

    var tool_tip = d3.tip()
        .attr("class", "d3-tip")
        .html(function(d) {
            code = d.id;
            if(DataByCountryID[code] !== undefined)
                return(d.properties.name + "<br>" + selected + ": $" + DataByCountryID[code].val.toLocaleString());
            else
                return(d.properties.name + "<br>No Data");
        });
    svg.call(tool_tip);

    projection = d3.geoEquirectangular()
        .translate([width/2, height/2])
        .scale(150);

    var path = d3.geoPath()
        .projection(projection);

    var testMap = svg.selectAll("path")
        .data(worldMap);

    testMap.enter().append("path")
        .merge(testMap)
        .attr("class", "map")
        .on('mouseover', tool_tip.show)
        .on('mouseout', tool_tip.hide)
        .on('click', function(d){
            code = d.id;
            byCountryChoropleth(code);
        })
        .attr("stroke", "black")
        .attr("d", path);

    svg.selectAll(".map").transition().duration(800)
        .style("fill", function(d){
            code = d.id;
            if(DataByCountryID[code] !== undefined)
                return color(DataByCountryID[code].val/1000000);
            else
                return "lightgrey";
        });

    centroids = worldMap.map(function (feature){
        return [feature.id, path.centroid(feature)];
    });

    CentersByID = {};
    centroids.forEach(function(d){CentersByID[d[0]]=d;});

    var colorList = ["#fff5f0","#fee0d2","#fcbba1","#fc9272","#fb6a4a","#ef3b2c","#cb181d","#a50f15","#67000d"];
    var labelList = [0, 1, 10, 50, 100, 250, 500, 1000, 2500, 5000];

    var rects = svg.selectAll(".bars")
        .data(colorList);

    rects.enter().append("rect")
        .attr("class", "bars")
        .merge(rects)
        .attr("height", 20)
        .attr("width", 20)
        .attr("x", width/10)
        .attr("y", function(d, i){
            return(400 - i*20);
        })
        .style("fill", function(d){
            return d;
        });

    var labels = svg.selectAll(".label")
        .data(labelList);

    labels.enter().append("text")
        .attr("class", "label")
        .merge(labels)
        .attr("x", width/10+25)
        .attr("y", function(d, i){
            return(423 - i*20);
        })
        .text(function(d){
            return(Math.round(d) + " Million")
        });

    labels.exit().remove();
    rects.exit().remove();
    testMap.exit().remove();

}

function byCountryChoropleth(code_2){
    DataByCountryID = {};
    if (selected === "Cocoa Exports")
        worldData = cocoa_Ex.filter(function(d){return (d.focus_country === code_2)});
    else if (selected === "Cocoa Imports")
        worldData = cocoa_Im.filter(function (d) {return (d.focus_country === code_2)});
    else if (selected === "Chocolate Exports")
        worldData = chocolate_Ex.filter(function (d) {return (d.focus_country === code_2)});
    else if (selected === "Chocolate Imports")
        worldData = chocolate_Im.filter(function (d) {return (d.focus_country === code_2)});

    worldData.forEach(function(d){DataByCountryID[d.other_country] = d;});

    svg.selectAll(".map").transition().duration(800)
        .style("fill", function(d){
            code = d.id;
            if(DataByCountryID[code] !== undefined)
                return color(DataByCountryID[code].val/1000000);
            else
                return "lightgrey";
        });

    sourceCenter = CentersByID[code_2][1];

    targetCenters = [];
    for (var i=0; i<worldData.length; i++){
        ID = worldData[i].other_country;
        if(CentersByID[ID] !== undefined)
            targetCenters.push(CentersByID[ID][1]);
    }

    var edge = svg.selectAll(".edge")
        .data(targetCenters);

    edge.enter().append("line")
        .attr("class", "edge")
        .merge(edge)
        .attr("stroke-width", 1)
        .style("stroke", "black")
        .attr("x1", sourceCenter[0])
        .attr("y1", sourceCenter[1])
        .attr("x2", function(d) {
            return d[0]; })
        .attr("y2", function(d) {
            return d[1]; });

    edge.exit().remove();
}